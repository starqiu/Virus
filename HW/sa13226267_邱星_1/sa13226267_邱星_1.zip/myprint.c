#include <stdio.h>
void my_print(char *s)
{
    printf(s);
    return;
}